package com.ssafy.Util;

public class SizeConstant {

    public static final int LIST_SIZE = 6;
    public static final int LIMITSIZE = 20;
    public static final int NAVIGATION_SIZE = 5;
}
