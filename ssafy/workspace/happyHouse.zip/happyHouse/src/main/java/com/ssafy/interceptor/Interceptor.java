package com.ssafy.interceptor;


public class Interceptor {

}
