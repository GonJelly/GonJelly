package com.ssafy.board.model.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {

	// 게시판 글 조회하기
	
	// 회원 '좋아요' 조회하기

}
