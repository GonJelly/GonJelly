package com.ssafy.board.model.service;

public interface BoardService {

}
