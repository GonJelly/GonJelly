package com.ssafy.board.model.service;

import com.ssafy.board.model.BuildInfoDto;
import com.ssafy.board.model.mapper.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class BoardServiceImpl implements BoardService{


}
