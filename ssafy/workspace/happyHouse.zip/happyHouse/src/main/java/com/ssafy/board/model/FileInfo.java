package com.ssafy.board.model;

public class FileInfo {
}
