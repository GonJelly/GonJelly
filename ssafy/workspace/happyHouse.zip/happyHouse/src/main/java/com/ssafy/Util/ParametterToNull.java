package com.ssafy.Util;

public class ParametterToNull {

}
