-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema todosns
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema todosns
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `todosns` DEFAULT CHARACTER SET utf8 ;
USE `todosns` ;

-- -----------------------------------------------------
-- Table `todosns`.`user`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `todosns`.`user` ;

CREATE TABLE IF NOT EXISTS `todosns`.`user` (
  `userid` VARCHAR(15) NOT NULL,
  `userpw` VARCHAR(30) NOT NULL,
  `name` VARCHAR(15) NOT NULL,
  `email` VARCHAR(30) NOT NULL,
  PRIMARY KEY (`userid`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `todosns`.`follow`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `todosns`.`follow` ;

CREATE TABLE IF NOT EXISTS `todosns`.`follow` (
  `follower` VARCHAR(15) NOT NULL,
  `following` VARCHAR(15) NOT NULL,
  INDEX `follow_user_fk_follower_idx` (`follower` ASC) VISIBLE,
  INDEX `follow_user_fk_following_idx` (`following` ASC) VISIBLE,
  CONSTRAINT `follow_user_fk_follower`
    FOREIGN KEY (`follower`)
    REFERENCES `todosns`.`user` (`userid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `follow_user_fk_following`
    FOREIGN KEY (`following`)
    REFERENCES `todosns`.`user` (`userid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `todosns`.`todo`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `todosns`.`todo` ;

CREATE TABLE IF NOT EXISTS `todosns`.`todo` (
  `todonum` INT NOT NULL AUTO_INCREMENT,
  `tyear` INT NOT NULL,
  `tmonth` INT NOT NULL,
  `tday` INT NOT NULL,
  `userid` VARCHAR(15) NOT NULL,
  `subject` VARCHAR(100) NOT NULL,
  `content` VARCHAR(300) NULL,
  PRIMARY KEY (`todonum`),
  INDEX `todo_user_fk_userid_idx` (`userid` ASC) VISIBLE,
  CONSTRAINT `todo_user_fk_userid`
    FOREIGN KEY (`userid`)
    REFERENCES `todosns`.`user` (`userid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `todosns`.`board`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `todosns`.`board` ;

CREATE TABLE IF NOT EXISTS `todosns`.`board` (
  `boardnum` INT NOT NULL AUTO_INCREMENT,
  `userid` VARCHAR(15) NOT NULL,
  `subject` VARCHAR(100) NOT NULL,
  `content` VARCHAR(300) NULL,
  `hit` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`boardnum`),
  INDEX `board_user_fk_userid_idx` (`userid` ASC) VISIBLE,
  CONSTRAINT `board_user_fk_userid`
    FOREIGN KEY (`userid`)
    REFERENCES `todosns`.`user` (`userid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `todosns`.`hurry`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `todosns`.`hurry` ;

CREATE TABLE IF NOT EXISTS `todosns`.`hurry` (
  `todonum` INT NOT NULL,
  `userid` VARCHAR(15) NOT NULL,
  INDEX `hurry_todo_fk_todonum_idx` (`todonum` ASC) VISIBLE,
  INDEX `hurry_user_fk_userid_idx` (`userid` ASC) VISIBLE,
  CONSTRAINT `hurry_todo_fk_todonum`
    FOREIGN KEY (`todonum`)
    REFERENCES `todosns`.`todo` (`todonum`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `hurry_user_fk_userid`
    FOREIGN KEY (`userid`)
    REFERENCES `todosns`.`user` (`userid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
