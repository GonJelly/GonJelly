INSERT INTO `todosns`.`user` (`userid`, `userpw`, `name`, `email`) 
VALUES  ('ssafy', '12345', '김싸피', 'abcd@ssafy.com'),
		('user01', '12345', '안유저', 'hello@naver.com'),
		('user02', '12345', '박유저', 'world@naver.com');
        
INSERT INTO `todosns`.`follow` (`follower`, `following`)
VALUES  ('ssafy', 'user01'),
		('ssafy', 'user02'),
        ('user02', 'user01');

INSERT INTO `todosns`.`todo` (`tyear`, `tmonth`, `tday`, `userid`, `subject`, `content`)
VALUES  ( 2022 ,  9, 27 , 'ssafy', '과제', 'jdbc 의뢰 내용 수행'),
		( 2022 ,  9, 28 , 'user02', '관통 프로젝트', '데이터베이스 관통 프로젝트 수행하기');


INSERT INTO `todosns`.`board` (`userid`, `subject`, `content`)
VALUES ( 'ssafy', '안녕하세요', '오늘 가입했어요오우'),
		 ( 'ssafy', '다른 분 없나요', '팔로우 해주세요');

INSERT INTO `todosns`.`hurry` (`todonum`, `userid`)
VALUES ( 1 , 'ssafy'),
		( 1 , 'user01'),
		( 1 , 'user02');

select * from `user`;
select * from follow;
select * from todo;
select * from board;
select * from hurry;