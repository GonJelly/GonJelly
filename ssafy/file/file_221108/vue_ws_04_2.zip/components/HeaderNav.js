export default {
  template: `
  <header>
    <nav class="header-nav">
      <div>
        <a href="index.html" class="logo">영화관리</a>
      </div>
      <div>
        <a href="create.html">영화등록</a>
        <a href="list.html">영화목록</a>
      </div>
    </nav>
  </header>
  `
}