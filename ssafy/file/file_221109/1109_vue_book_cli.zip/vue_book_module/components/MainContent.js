export default {
  template: `
    <div>
        <ul>
            <li><a href="./create.html">도서 등록</a></li>
            <li><a href="./list.html">도서 목록</a></li>
        </ul>
    </div>
    `
};
