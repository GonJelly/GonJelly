<template>
  <div class="header">
    <a href="/"> <img src="@/assets/ssafy_logo.png" class="ssafy_logo" /></a>
    <p class="logo">도서관리</p>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
