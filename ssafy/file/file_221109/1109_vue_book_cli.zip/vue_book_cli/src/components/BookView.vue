<template>
  <div class="regist">
    <h1 class="underline">SSAFY 도서 정보</h1>
    <!-- TODO : 도서 상세조회 화면 구성하기 -->
  </div>
</template>

<script>
export default {
  props: {
    isbn: {
      type: String,
    },
  },
  created() {
    // const params = new URL(document.location).searchParams;
    // TODO : 도서조회페이지가 부착되기 전에 상세조회 도서 정보 가져오기
    // 로컬스토리지 저장소에서 도서목록 가져오기
    // 도서목록 순차 순회하면서 해당 도서 정보 가져와서 설정하기
  },
  methods: {
    movePage() {
      this.$emit("moveList", true);
    },
    moveToModi(isbn) {
      this.$emit("moveToModi", isbn);
    },
    removeBook(isbn) {
      this.$emit("deleteBook", isbn);
    },
  },
};
</script>

<style></style>
